module.exports = {
  id: 'generate-token',
  name: 'Generate Token on Create',
  type: 'hook',
  event: 'items.create',
  collection: 'Acces',
  action: async (input, { services, database, schema }) => {
    // Générer un token unique
    const token = crypto.randomUUID();
    
    // Ajouter le token à l'input si il n'existe pas
    if (!input.payload.Token) {
      input.payload.Token = token;
    }
    
    return input;
  }
};
